<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona Główna</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="grid-container">
    <header>
        Strona Główna
    </header>
    <div id="item4">
    
    
    </div id="item4">
    <main>
    <ul>
        <li><a href="main.php"> Strona Główna</a></li>
            <li>
                <a href="modyfikowanie.php">Dodawanie i usuwanie uczniow</a>
            </li>
            <li><a href="dodawanie_klas.php"> Dodawnie i usuwanie klas</a></li>
            <li><a href="wszyscy.php"> Wszyscy uczniowie</a></li>
        </ul>
        
        <div id="zapraszamy">
            <div></div>
            <div id="spacerdiv"><a id="spacer" href="https://www.google.com/maps/@49.9510139,18.6112789,3a,75y,314.18h,90.76t/data=!3m6!1e1!3m4!1sAF1QipNlEg-WRoRouTKPuyD7e9FCoBmOCZnZvuyg_x0M!2e10!7i6000!8i3000?hl=pl-PL&entry=ttu">Zapraszamy na wirtualny <br> spacer po naszej szkole!</a></div>
            <img src="zapraszamy.png" id="zapraszamyimg" alt="mojamorda">
        </div>
       
    </main>
    <div id="rightBanner">

    </div>
    <div id="item7"></div>
    <footer>
    ZS6 Sobieski - email: aaaaa@aaaa.com, Numer Telefonu: 112
    </footer>
    <div id="item9"></div>
</div>
</body>
</html>