<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        Nazwisko: <input type="text" name="query"><br>
    
        <input type="submit" value="WYŚLIJ">
    </form>
    <table>
    <td width="50" align="center" bgcolor="e5e5e5">imie</td>
    <td width="100" align="center" bgcolor="e5e5e5">nazwisko</td>
    <td width="100" align="center" bgcolor="e5e5e5">ulica</td>
    <td width="100" align="center" bgcolor="e5e5e5">numer_domu</td>
    <td width="100" align="center" bgcolor="e5e5e5">numer_lokalu</td>
    <td width="100" align="center" bgcolor="e5e5e5">miejscowosc</td>
    <td width="100" align="center" bgcolor="e5e5e5">klasa</td><tr>
    <?php
    $host = 'localhost';
    $login = 'root';
    $password = '';
    $database = '2pb';

    

    $conn = mysqli_connect($host, $login, $password, $database);
    if(!$conn){
        echo "blad";
    }else{

    $query= $_POST["query"];
    $sql = "SELECT * FROM `uczniowie` WHERE nazwisko like '".$query."%'";
    $result = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_assoc($result)){
        
        $imie  = $row['imie'];
        $nazwisko = $row['nazwisko'];
        $ulica = $row['ulica'];
        $numer_domu = $row['numer_domu'];
        $numer_lokalu = $row['numer_lokalu'];
        $miejscowosc= $row['miejscowosc'];
        $klasa = $row['klasa'];
      
        ?>

<td	width="50" align="center"><?=$imie?></td>
<td width="100" align="center"><?=$nazwisko?></td>
<td width="100" align="center"><?=$ulica?></td>
<td width="100" align="center"><?=$numer_domu?></td>
<td width="100" align="center"><?=$numer_lokalu?></td>
<td width="100" align="center"><?=$miejscowosc?></td>
<td width="100" align="center"><?=$klasa?></td>

</tr><tr>

		
<?php
	}}

?>


</tr></table>
   
</body>
</html> 